Hi Microsoft Azure Developer,

two steps for you:

1. Before you run the UWP application, please set the connection string for your Storage Account in the file

WiredBrainCoffee.AdminApp\Settings\AppSettings.cs

2. Before you run the ASP.NET Core web application, please set the connection string for your Storage Account in the file

WiredBrainCoffee.WebApp\appsettings.json


If you have any questions, please ask those questions in the discussion tab on the homepage of this course at www.pluralsight.com.

Thanks,
Thomas Claudius Huber
www.thomasclaudiushuber.com
