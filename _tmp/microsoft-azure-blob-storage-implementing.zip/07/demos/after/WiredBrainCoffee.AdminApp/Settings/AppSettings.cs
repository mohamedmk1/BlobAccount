﻿namespace WiredBrainCoffee.AdminApp.Settings
{
  class AppSettings
  {
    // TODO: Please add the connnection string for your Storage Account here
    public static readonly string ConnectionString = "";
  }
}
