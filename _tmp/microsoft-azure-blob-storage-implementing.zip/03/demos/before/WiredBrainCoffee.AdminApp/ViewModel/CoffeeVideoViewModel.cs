﻿namespace WiredBrainCoffee.AdminApp.ViewModel
{
  public class CoffeeVideoViewModel : ViewModelBase
  {
    public string BlobName { get; set; }

    public string BlobUri { get; set; }
  }
}
