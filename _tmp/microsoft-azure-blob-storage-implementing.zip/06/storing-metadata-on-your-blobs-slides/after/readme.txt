Hi Microsoft Azure Developer,

before you run the UWP application, please set the connection string for your Storage Account in the file

WiredBrainCoffee.AdminApp\Settings\AppSettings.cs

Else you'll get an error when you try to upload a video, as there's just an empty connection string in that AppSettings.cs file.

If you have any questions, please ask those questions in the discussion tab on the homepage of this course at www.pluralsight.com.

Thanks,
Thomas Claudius Huber
www.thomasclaudiushuber.com
